create extension if not exists pgcrypto;
create table if not exists public.resumes (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 title text not null check (char_length(title) between 1 and 150),
 content text not null check (char_length(content) between 1 and 30000),
 created_at timestamptz not null default now()
);
create index if not exists resumes_user_id_idx on public.resumes(user_id);
alter table public.resumes enable row level security;
revoke all on public.resumes from anon, authenticated;
grant select,insert,delete on public.resumes to authenticated;
create policy "owner_select" on public.resumes for select to authenticated using ((select auth.uid()) = user_id);
create policy "owner_insert" on public.resumes for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "owner_delete" on public.resumes for delete to authenticated using ((select auth.uid()) = user_id);
