import { createClient } from '@supabase/supabase-js';
import type { Request, Response, NextFunction } from 'express';
import { z } from 'zod';
export const resumeSchema = z.object({title:z.string().min(1).max(150),content:z.string().min(1).max(30000)}).strict();
export const aiSchema = z.object({jobDescription:z.string().min(1).max(12000),evidence:z.string().min(1).max(12000)}).strict();
export function userClient(jwt:string) {
  return createClient(process.env.SUPABASE_URL!,process.env.SUPABASE_PUBLISHABLE_KEY!,{
    global:{headers:{Authorization:`Bearer ${jwt}`}},
    auth:{persistSession:false,autoRefreshToken:false}
  });
}
declare global { namespace Express { interface Request { userId?:string; db?:ReturnType<typeof userClient> } } }
export async function requireAuth(req:Request,res:Response,next:NextFunction) {
  const match=/^Bearer ([A-Za-z0-9._-]+)$/.exec(req.header('authorization')||'');
  if(!match){res.status(401).json({error:'Unauthorized'});return;}
  try {
    const db=userClient(match[1]);
    const {data,error}=await db.auth.getUser(match[1]);
    if(error||!data.user){res.status(401).json({error:'Unauthorized'});return;}
    req.userId=data.user.id;req.db=db;next();
  } catch {res.status(401).json({error:'Unauthorized'});}
}
