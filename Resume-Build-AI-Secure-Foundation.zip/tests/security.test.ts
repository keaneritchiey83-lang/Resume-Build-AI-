import {describe,it,expect} from 'vitest';
import {resumeSchema,aiSchema} from '../src/security.js';
describe('API input security',()=>{
 it('rejects client-supplied owner IDs (API3)',()=>expect(resumeSchema.safeParse({title:'Test',content:'Sample',user_id:'victim'}).success).toBe(false));
 it('rejects oversized documents (API4)',()=>expect(resumeSchema.safeParse({title:'Test',content:'x'.repeat(30001)}).success).toBe(false));
 it('rejects extra AI request fields',()=>expect(aiSchema.safeParse({jobDescription:'job',evidence:'work',apiKey:'leak'}).success).toBe(false));
});
