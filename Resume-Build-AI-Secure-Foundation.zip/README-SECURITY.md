# Secure API foundation — development only
This is an additive starter, not a production-certified system. No files were pushed to GitHub.
## Install
Node.js 22+ recommended. `npm install`; `npm run build`; `npm test`.
Copy `.env.example` to `.env` and fill values privately. NEVER commit `.env`.
Create a separate Supabase development project, enable email verification and MFA where appropriate, and run the SQL migration in its SQL editor.
Run `npm run dev` and check GET /health.
For protected calls, obtain a user access token through Supabase Auth and send `Authorization: Bearer <token>`.
Set ALLOWED_ORIGIN to the exact trusted frontend origin, not `*`. Verify ChatGPT Sites supports authenticated requests to this external backend before connecting it.
## Not yet complete
No signup/login frontend, MFA enforcement, document export, web research, interview API, privacy deletion/export, durable distributed rate limits, security audit logging, full OWASP suite, live cross-user integration tests, backups, deployment configuration, or penetration testing.
Before production: add RLS integration tests with two test users, validate token expiry and revocation, enforce per-user AI quotas, use shared rate-limit storage, assess provider retention, add privacy workflows, monitor costs and incidents, test prompt injection, review hosting and CORS, and run independent security review.
The AI endpoint sends supplied evidence to the AI provider; users must explicitly consent and receive accurate privacy disclosures.
